#include "slist.h"
#include <stdlib.h>

SList slist_crear() {
  return NULL;
}

void slist_destruir(SList lista) {
  SNodo *nodoAEliminar;
  while (lista != NULL) {
    nodoAEliminar = lista;
    lista = lista->sig;
    free(nodoAEliminar);
  }
}

int slist_vacia(SList lista) {
  return lista == NULL;
}

SList slist_agregar_final(SList lista, int dato) {
  SNodo *nuevoNodo = malloc(sizeof(SNodo));
  nuevoNodo->dato = dato;
  nuevoNodo->sig = NULL;

  if (lista == NULL)
    return nuevoNodo;

  SList nodo = lista;
  for (;nodo->sig != NULL;nodo = nodo->sig);
  /* ahora 'nodo' apunta al ultimo elemento en la lista */

  nodo->sig = nuevoNodo;
  return lista;
}

SList slist_agregar_inicio(SList lista, int dato) {
  SNodo *nuevoNodo = malloc(sizeof(SNodo));
  nuevoNodo->dato = dato;
  nuevoNodo->sig = lista;
  return nuevoNodo;
}

void slist_recorrer(SList lista, FuncionVisitante visit) {
  for (SNodo *nodo = lista; nodo != NULL; nodo = nodo->sig)
    visit(nodo->dato);
}

/**
* slist_concatenar: SList, SList -> SList
* La funcion toma dos listas y las concatena
* modificando la primera.
*/

SList slist_concatenar(SList lista1, SList lista2) {
  if(slist_vacia(lista1)) return lista2;
  if(slist_vacia(lista2)) return lista1;
  
  SList iter = lista1;
  for(; iter->sig != NULL; iter = iter->sig); //itero hasta el ultimo nodo
                                              //de lista1
  iter->sig = lista2; //el nodo siguiente ahora es el primero de lista2
  return lista1;
}

/**
 * Copia la lista en una nueva lista de orden inverso.
 */
SList slist_reverso_copia(SList lista) {
  SList nuevaLista = slist_crear();
  for (SNodo* it = lista; it != NULL; it = it->sig)
    nuevaLista = slist_agregar_inicio(nuevaLista, it->dato);
  return nuevaLista;
}


/**
 * Modifica la lista dada, obteniendo un orden inverso.
 * Implementacion recursiva.
 */
SList slist_reverso_recursivo(SList lista) {
  if (lista == NULL || lista->sig == NULL)
    return lista;
  SNodo* ultimo = slist_reverso_recursivo(lista->sig);
  lista->sig->sig = lista;
  lista->sig = NULL;
  return ultimo;
}


/**
 * Modifica la lista dada, obteniendo un orden inverso.
 * Implementacion iterativa.
 */
SList slist_reverso(SList lista) {
  SNodo* reversa = NULL;
  for (SNodo* it = lista; it != NULL;) {
    SNodo* resto = it->sig;
    it->sig = reversa;
    reversa = it;
    it = resto;
  }
  return reversa;
}

