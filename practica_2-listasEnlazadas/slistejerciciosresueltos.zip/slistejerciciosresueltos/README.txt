Compilamos primero la implementación:
-----------------
$ gcc -c -Wall -Wextra -Werror slist.c
-----------------

Si todo anduvo bien, generó un slist.o en el directorio.

Luego, podemos compilar el archivo main.c, dándole
nombre "main" al binario (en lugar de "a.out"), y
diciendole que tiene que tomar algunas funciones
de slist.o:
----------------------------
$ gcc -Wall -Wextra -Werror -o main main.c slist.o
----------------------------

Ejecutamos "main" para verificar que haga lo esperado:
---------
$ ./main

Output:
    Testing para funciones en reverso.c:
    slist_reverso_copia: 1 2 3 4 5  => 5 4 3 2 1 
    slist_reverso_recursivo: 1 2 3 4 5  => 5 4 3 2 1 
    slist_reverso: 1 2 3 4 5  => 5 4 3 2 1 
    Testing para funciones en concatenar.c:
    lista1 => 1 2 
    lista2 => 3 4 
    Concatenando...
    lista1 => 1 2 3 4 
-----------------------------------------------------------