#ifndef __SLIST_H__
#define __SLIST_H__

#include <stddef.h>

typedef void (*FuncionVisitante) (int dato);

typedef struct _SNodo {
  int dato;
  struct _SNodo *sig;
} SNodo;

typedef SNodo *SList;

/**
 * Devuelve una lista vacía.
 */
SList slist_crear();

/**
 * Destruccion de la lista.
 */
void slist_destruir(SList lista);

/**
 * Determina si la lista es vacía.
 */
int slist_vacia(SList lista);

/**
 * Agrega un elemento al final de la lista.
 */
SList slist_agregar_final(SList lista, int dato);

/**
 * Agrega un elemento al inicio de la lista.
 */
SList slist_agregar_inicio(SList lista, int dato);

/**
 * Recorrido de la lista, utilizando la funcion pasada.
 */
void slist_recorrer(SList lista, FuncionVisitante visit);

/*********
//slist_concatenar: SList, SList -> SList
//La funcion toma dos listas y las concatena
//modificando la primera.
*********/

SList slist_concatenar(SList lista1, SList lista2);

/**
 * Copia la lista en una nueva lista de orden inverso.
 */
SList slist_reverso_copia(SList lista);

/**
 * Modifica la lista dada, obteniendo un orden inverso.
 * Implementacion recursiva.
 */
SList slist_reverso_recursivo(SList lista);

/**
 * Modifica la lista dada, obteniendo un orden inverso.
 * Implementacion iterativa.
 */
SList slist_reverso(SList lista);


#endif /* __SLIST_H__ */
